# 📗 Excel Básico — Guía Completa Desde Cero (Paso a Paso)

**🎁 EXCLUSIVO PARA PATREONS — NIVEL ORO Y VIP**

¿Nunca has usado Excel o lo usas muy básicamente? Esta guía te lleva desde CERO hasta que puedas crear tus propias bases de datos, tablas y gráficos como un profesional.

## 📖 Lo que aprenderás

### Módulo 1: Fundamentos
- Navegación y atajos de teclado esenciales
- Formatos de celda profesionales
- Manejo de hojas y libros

### Módulo 2: Fórmulas Esenciales
- SUMA, PROMEDIO, CONTAR, MAX, MIN
- Referencias absolutas vs relativas ($)
- Funciones de texto (EXTRAE, IZQUIERDA, DERECHA)

### Módulo 3: Tablas y Datos
- Crear y formatear tablas
- Filtros y ordenamiento
- Validación de datos

### Módulo 4: Gráficos
- Gráficos de barras, líneas y pastel
- Personalización profesional
- Minigráficos

## 📂 Archivos incluidos
✅ Guía PDF completa con portada profesional
✅ 5 ejercicios prácticos con soluciones
✅ Plantillas descargables .xlsx

## 💰 Precio en tienda: $5 — TÚ lo tienes GRATIS aquí

👇 **Descarga el PDF en los archivos adjuntos abajo**

---

**💡 Tip:** Practica 15 minutos al día con los ejercicios y en una semana estarás manejando Excel como todo un profesional.

*Próxima entrega: 📙 Excel Intermedio — Fórmulas Avanzadas*
